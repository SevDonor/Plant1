#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Smart Plant Monitor — Ứng dụng Desktop Python (Tkinter + PySerial + SQLite).

Kết nối trực tiếp ESP32 qua cổng COM USB để giám sát 5 thông số môi trường
(Độ ẩm đất %, Nhiệt độ °C, Độ ẩm không khí %RH, Ánh sáng Lux, Áp suất hPa),
cảm biến cân bằng/rung MPU-6050, micro INMP441, bus I2C và trạm tưới an toàn P3.
"""

from __future__ import annotations

import csv
import datetime
import json
import math
import os
import queue
import re
import sqlite3
import threading
import tkinter as tk
from collections import deque
from tkinter import filedialog, messagebox, ttk

try:
    import serial
    import serial.tools.list_ports

    HAS_PYSERIAL = True
except ImportError:
    serial = None
    HAS_PYSERIAL = False

try:
    import winreg
except ImportError:
    winreg = None


DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plant_telemetry.db")

THEMES = {
    "dark": {
        "bg_app": "#090E1A",
        "bg_sidebar": "#0D1424",
        "bg_card": "#131D33",
        "bg_inner": "#0F172A",
        "bg_hover": "#1E293B",
        "border": "#26344D",
        "text": "#F1F5F9",
        "muted": "#94A3B8",
        "emerald": "#22C55E",
        "emerald_tint": "#112925",
        "sky": "#38BDF8",
        "sky_tint": "#12273D",
        "amber": "#F59E0B",
        "amber_tint": "#2A2116",
        "gold": "#EAB308",
        "gold_tint": "#272315",
        "violet": "#A78BFA",
        "violet_tint": "#211E3A",
        "rose": "#EF4444",
        "rose_tint": "#2E1721",
        "grid_line": "#1D293E",
        "btn_fg_dark": "#041524",
    },
    "light": {
        "bg_app": "#EEF3F8",
        "bg_sidebar": "#F8FAFC",
        "bg_card": "#FFFFFF",
        "bg_inner": "#F1F5F9",
        "bg_hover": "#E2E8F0",
        "border": "#CBD5E1",
        "text": "#0F172A",
        "muted": "#475569",
        "emerald": "#16A34A",
        "emerald_tint": "#DCFCE7",
        "sky": "#0284C7",
        "sky_tint": "#E0F2FE",
        "amber": "#D97706",
        "amber_tint": "#FEF3C7",
        "gold": "#CA8A04",
        "gold_tint": "#FEF9C3",
        "violet": "#7C3AED",
        "violet_tint": "#EDE9FE",
        "rose": "#DC2626",
        "rose_tint": "#FEE2E2",
        "grid_line": "#E2E8F0",
        "btn_fg_dark": "#FFFFFF",
    },
}

METRICS_CONFIG = {
    "soil_pct": {
        "title": "1. Độ ẩm đất",
        "icon_title": "🌱 Ẩm đất",
        "unit": "%",
        "y_min": 0.0,
        "y_max": 100.0,
        "ideal": (40.0, 75.0),
        "threshold": 30.0,
        "color_key": "emerald",
        "tint_key": "emerald_tint",
        "sub_default": "GPIO34 · %",
    },
    "temp_c": {
        "title": "2. Nhiệt độ",
        "icon_title": "🌡 Nhiệt độ",
        "unit": "°C",
        "y_min": 15.0,
        "y_max": 45.0,
        "ideal": (20.0, 32.0),
        "threshold": 32.0,
        "color_key": "amber",
        "tint_key": "amber_tint",
        "sub_default": "AHT20 · °C",
    },
    "air_hum_pct": {
        "title": "3. Độ ẩm không khí",
        "icon_title": "💨 Ẩm KK",
        "unit": "%",
        "y_min": 20.0,
        "y_max": 95.0,
        "ideal": (45.0, 75.0),
        "threshold": 75.0,
        "color_key": "sky",
        "tint_key": "sky_tint",
        "sub_default": "AHT20 · %RH",
    },
    "light_lux": {
        "title": "4. Cường độ ánh sáng",
        "icon_title": "☀️ Ánh sáng",
        "unit": "Lux",
        "y_min": 0.0,
        "y_max": 1500.0,
        "ideal": (200.0, 900.0),
        "threshold": 800.0,
        "color_key": "gold",
        "tint_key": "gold_tint",
        "sub_default": "BH1750 · Lux",
    },
    "press_hpa": {
        "title": "5. Áp suất khí quyển",
        "icon_title": "🌤 Áp suất",
        "unit": "hPa",
        "y_min": 985.0,
        "y_max": 1030.0,
        "ideal": (1002.0, 1018.0),
        "threshold": 1000.0,
        "color_key": "violet",
        "tint_key": "violet_tint",
        "sub_default": "BMP280 · hPa",
    },
}

I2C_DEVICES = [
    ("0x23", "BH1750 (0x23)"),
    ("0x38", "AHT20 (0x38)"),
    ("0x77", "BMP280 (0x76/77)"),
    ("0x68", "MPU-6050 (0x68)"),
    ("0x3C", "OLED-1 (0x3C)"),
    ("0x3D", "OLED-2 (0x3D)"),
]

NUM_RE = r"([+-]?\d+(?:\.\d+)?)"


def detect_serial_ports() -> tuple[list[tuple[str, str, bool]], str | None]:
    """Liệt kê các cổng COM hiện có và tự động đề xuất cổng ESP32."""
    keywords = ("cp210", "ch340", "ch910", "ftdi", "usb serial", "uart", "esp32", "usb-enhanced", "jtag")
    items: list[tuple[str, str, bool]] = []
    preferred: str | None = None

    if HAS_PYSERIAL:
        ports = sorted(serial.tools.list_ports.comports(), key=lambda p: p.device)
        for p in ports:
            desc = p.description or "Serial Port"
            text = f"{desc} {p.hwid or ''}".lower()
            is_esp = any(k in text for k in keywords)
            label = f"{p.device} — {desc}" + (" ★" if is_esp else "")
            items.append((p.device, label, is_esp))
            if is_esp and preferred is None:
                preferred = p.device
        if not preferred and items:
            preferred = items[0][0]
        return items, preferred

    # Fallback nhẹ qua Windows Registry nếu chưa cài pyserial
    if winreg is not None:
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DEVICEMAP\SERIALCOMM") as key:
                idx = 0
                while True:
                    try:
                        _, val, _ = winreg.EnumValue(key, idx)
                        items.append((val, f"{val} (Cần pyserial)", False))
                        idx += 1
                    except OSError:
                        break
        except OSError:
            pass
    if items:
        preferred = items[0][0]
    return items, preferred


class TelemetryDatabase:
    """Quản lý lưu trữ dữ liệu cảm biến thực tế trong SQLite (plant_telemetry.db)."""

    def __init__(self, db_path: str):
        self.conn = sqlite3.connect(db_path)
        self._init_schema()

    def _init_schema(self):
        cur = self.conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS sensor_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                source TEXT NOT NULL,
                soil_pct REAL,
                soil_mv INTEGER,
                soil_adc INTEGER,
                temp_c REAL,
                air_hum_pct REAL,
                light_lux REAL,
                press_hpa REAL,
                tilt_deg REAL,
                dyn_g REAL,
                tank_ok INTEGER,
                pump_on INTEGER
            )
            """
        )
        self.conn.commit()

    def insert_record(self, rec: dict):
        cur = self.conn.cursor()
        cur.execute(
            """
            INSERT INTO sensor_records (
                timestamp, source, soil_pct, soil_mv, soil_adc, temp_c,
                air_hum_pct, light_lux, press_hpa, tilt_deg, dyn_g, tank_ok, pump_on
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rec["timestamp"],
                rec["source"],
                rec.get("soil_pct"),
                rec.get("soil_mv"),
                rec.get("soil_adc"),
                rec.get("temp_c"),
                rec.get("air_hum_pct"),
                rec.get("light_lux"),
                rec.get("press_hpa"),
                rec.get("tilt_deg"),
                rec.get("dyn_g"),
                None if rec.get("tank_ok") is None else int(bool(rec["tank_ok"])),
                int(bool(rec.get("pump_on", False))),
            ),
        )
        self.conn.commit()

    def fetch_recent(self, limit_n: int = 300) -> list[tuple]:
        cur = self.conn.cursor()
        cur.execute(
            """
            SELECT id, timestamp, source, soil_pct, soil_mv, temp_c, air_hum_pct,
                   light_lux, press_hpa, tilt_deg, tank_ok, pump_on
            FROM sensor_records
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit_n,),
        )
        return cur.fetchall()

    def clear_all(self):
        self.conn.execute("DELETE FROM sensor_records")
        self.conn.commit()

    def close(self):
        self.conn.close()


class TelemetryParser:
    """Phân tích gói tin JSON và dòng text Serial từ các firmware ESP32 trong sensor/."""

    @staticmethod
    def _pick_float(d: dict, *paths) -> float | None:
        for path in paths:
            cur = d
            for part in path.split("."):
                if isinstance(cur, dict) and part in cur:
                    cur = cur[part]
                else:
                    cur = None
                    break
            if isinstance(cur, (int, float)) and not math.isnan(cur):
                return float(cur)
        return None

    @classmethod
    def parse_line(cls, line: str) -> dict:
        """Trả về dict gồm các trường cập nhật được (`env_updated`, `imu_updated`, `mic_updated`, `i2c_addr`, ...)."""
        out: dict = {"env_updated": False, "imu_updated": False, "mic_updated": False}
        s = line.strip()
        if not s:
            return out

        # 1. Định dạng JSON Telemetry (hỗ trợ cả gói testSTM32: type="env" / "mpu" / event="SCAN")
        if s.startswith("{") and s.endswith("}"):
            try:
                j = json.loads(s)
                if isinstance(j, dict):
                    pkt_type = j.get("type")
                    if j.get("event") == "SCAN" and isinstance(j.get("addrs"), list):
                        norm_addrs = []
                        for a in j["addrs"]:
                            if isinstance(a, str):
                                addr_u = a.strip().upper().replace("0X", "0x")
                                if addr_u == "0x76":
                                    addr_u = "0x77"
                                elif addr_u == "0x69":
                                    addr_u = "0x68"
                                norm_addrs.append(addr_u)
                        out["i2c_addrs"] = norm_addrs
                        return out

                    if pkt_type == "env":
                        if j.get("aht_ok", True):
                            v_t = cls._pick_float(j, "aht_t", "temp_c")
                            v_h = cls._pick_float(j, "aht_h", "air_hum_pct")
                            if v_t is not None:
                                out["temp_c"] = v_t
                                out["env_updated"] = True
                            if v_h is not None:
                                out["air_hum_pct"] = v_h
                                out["env_updated"] = True
                        if j.get("bmp_ok", True):
                            v_p = cls._pick_float(j, "bmp_p", "press_hpa")
                            if v_p is not None:
                                out["press_hpa"] = v_p
                                out["env_updated"] = True
                            if "temp_c" not in out:
                                v_bt = cls._pick_float(j, "bmp_t")
                                if v_bt is not None:
                                    out["temp_c"] = v_bt
                                    out["env_updated"] = True
                        if j.get("bh_ok", True):
                            v_lux = cls._pick_float(j, "lux", "light_lux")
                            if v_lux is not None:
                                out["light_lux"] = v_lux
                                out["env_updated"] = True
                        return out

                    if pkt_type != "mpu":
                        mapping = {
                            "soil_pct": ("soil_pct", "soil", "soil_moisture.percent"),
                            "soil_mv": ("soil_mv", "mv"),
                            "soil_adc": ("soil_adc", "adc", "soil_moisture.adc"),
                            "temp_c": ("temp_c", "temp", "temperature", "aht_t", "temp_pressure.temp_c"),
                            "air_hum_pct": ("air_hum_pct", "air_hum", "hum", "humidity", "aht_h"),
                            "light_lux": ("light_lux", "lux", "light_intensity_lux"),
                            "press_hpa": ("press_hpa", "press", "pressure", "bmp_p", "temp_pressure.pressure_hpa"),
                        }
                        for target, keys in mapping.items():
                            val = cls._pick_float(j, *keys)
                            if val is not None:
                                out[target] = int(val) if target in ("soil_mv", "soil_adc") else val
                                if target not in ("soil_mv", "soil_adc"):
                                    out["env_updated"] = True

                    for k in ("roll", "pitch", "ax", "ay", "az", "dyn_g", "tilt_deg"):
                        v = cls._pick_float(j, k, f"acceleration.{k}")
                        if v is not None:
                            out[k] = v
                            out["imu_updated"] = True
                    if "dyn_g" not in out and all(k in out for k in ("ax", "ay", "az")):
                        out["dyn_g"] = abs(math.sqrt(out["ax"] ** 2 + out["ay"] ** 2 + out["az"] ** 2) - 1.0)

                    if isinstance(j.get("tank_ok"), bool):
                        out["tank_ok"] = j["tank_ok"]
                    if isinstance(j.get("pump_on"), bool):
                        out["pump_on"] = j["pump_on"]
                    if isinstance(j.get("pump_phase"), str):
                        out["pump_phase"] = j["pump_phase"]
                    if isinstance(j.get("consecutive_cycles"), int):
                        out["cycles"] = j["consecutive_cycles"]

                    rms = cls._pick_float(j, "rms")
                    peak = cls._pick_float(j, "peak")
                    dbfs = cls._pick_float(j, "dbfs")
                    if rms is not None:
                        out["rms"] = int(rms)
                        out["mic_updated"] = True
                    if peak is not None:
                        out["peak"] = int(peak)
                    if dbfs is not None:
                        out["dbfs"] = dbfs
                    return out
            except json.JSONDecodeError:
                pass

        # 2. Định dạng all_in_one (sensor/src/main.cpp) - [NHÓM 1]
        if "[NHÓM 1]" in s:
            m_lux = re.search(rf"Ánh sáng:\s*{NUM_RE}\s*Lux", s, re.I)
            m_aht = re.search(rf"AHT20:\s*{NUM_RE}°C,\s*{NUM_RE}%RH", s, re.I)
            m_bmp = re.search(rf"BMP280:\s*{NUM_RE}\s*hPa", s, re.I)
            m_soil = re.search(rf"Đất:\s*{NUM_RE}%\s*\((\d+)mV\)", s, re.I)
            if m_lux:
                out["light_lux"] = float(m_lux.group(1))
                out["env_updated"] = True
            if m_aht:
                out["temp_c"] = float(m_aht.group(1))
                out["air_hum_pct"] = float(m_aht.group(2))
                out["env_updated"] = True
            if m_bmp:
                out["press_hpa"] = float(m_bmp.group(1))
                out["env_updated"] = True
            if m_soil:
                out["soil_pct"] = float(m_soil.group(1))
                out["soil_mv"] = int(m_soil.group(2))
                out["env_updated"] = True

        # 3. Định dạng riêng Nhóm 1 (sensor/1_env_sensors/src/main.cpp)
        if "[BH1750]" in s:
            m = re.search(rf"{NUM_RE}\s*Lux", s, re.I)
            if m:
                out["light_lux"] = float(m.group(1))
                out["env_updated"] = True
        if "[AHT20]" in s:
            m = re.search(rf"{NUM_RE}\s*°C.*?\s{NUM_RE}\s*%RH", s, re.I)
            if m:
                out["temp_c"] = float(m.group(1))
                out["air_hum_pct"] = float(m.group(2))
                out["env_updated"] = True
        if "[BMP280]" in s:
            m = re.search(rf"{NUM_RE}\s*hPa", s, re.I)
            if m:
                out["press_hpa"] = float(m.group(1))
                out["env_updated"] = True
        if "[SOIL]" in s:
            m = re.search(rf"{NUM_RE}\s*%.*?(\d+)\s*mV.*?ADC=(\d+)", s, re.I)
            if m:
                out["soil_pct"] = float(m.group(1))
                out["soil_mv"] = int(m.group(2))
                out["soil_adc"] = int(m.group(3))
                out["env_updated"] = True

        # 4. Định dạng MPU-6050 ([NHÓM 2 MPU-...] / [CAL] / [RAW] / Plotter CSV)
        m_mpu = re.search(rf"Roll:\s*{NUM_RE}°?\s*Pitch:\s*{NUM_RE}°?", s, re.I)
        if m_mpu:
            out["roll"] = float(m_mpu.group(1))
            out["pitch"] = float(m_mpu.group(2))
            out["imu_updated"] = True
            m_acc = re.search(rf"X=\s*{NUM_RE}\s*Y=\s*{NUM_RE}\s*Z=\s*{NUM_RE}", s, re.I)
            if m_acc:
                ax, ay, az = float(m_acc.group(1)), float(m_acc.group(2)), float(m_acc.group(3))
                out.update({"ax": ax, "ay": ay, "az": az})
                out["dyn_g"] = abs(math.sqrt(ax * ax + ay * ay + az * az) - 1.0)

        m_plot = re.search(rf"Roll:{NUM_RE},Pitch:{NUM_RE},Ax:{NUM_RE},Ay:{NUM_RE},Az:{NUM_RE}", s, re.I)
        if m_plot:
            ax, ay, az = float(m_plot.group(3)), float(m_plot.group(4)), float(m_plot.group(5))
            out.update(
                {
                    "roll": float(m_plot.group(1)),
                    "pitch": float(m_plot.group(2)),
                    "ax": ax,
                    "ay": ay,
                    "az": az,
                    "dyn_g": abs(math.sqrt(ax * ax + ay * ay + az * az) - 1.0),
                    "imu_updated": True,
                }
            )

        # 5. Định dạng Micro INMP441 ([NHÓM 3 INMP441] hoặc [INMP441 Gain=...])
        m_mic = re.search(rf"RMS:\s*(\d+)\s*\|\s*Peak:\s*(\d+)(?:\s*\|\s*{NUM_RE}\s*dBFS)?", s, re.I)
        if m_mic:
            rms = int(m_mic.group(1))
            peak = int(m_mic.group(2))
            dbfs = float(m_mic.group(3)) if m_mic.group(3) else (20.0 * math.log10(rms / 32768.0) if rms > 1 else -96.0)
            out.update({"rms": rms, "peak": peak, "dbfs": dbfs, "mic_updated": True})

        # 6. Kết quả I2C Scanner ([+] Địa chỉ 0x23 : ...)
        m_i2c = re.search(r"Địa chỉ\s+(0x[0-9A-Fa-f]{2})", s, re.I)
        if m_i2c:
            addr = m_i2c.group(1).upper().replace("0X", "0x")
            out["i2c_addr"] = "0x77" if addr == "0x76" else addr

        return out


class SmartPlantDesktopApp:
    """Ứng dụng Desktop Python Tkinter giám sát cây trồng qua USB Serial ESP32."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Smart Plant Monitor — Giám sát Môi trường Cây trồng (ESP32 USB)")
        self.root.geometry("1360x800")
        self.root.minsize(1140, 690)

        self.theme_name = "dark"
        self.db = TelemetryDatabase(DB_PATH)

        # Trạng thái Serial
        self.ser = None
        self.reader_thread: threading.Thread | None = None
        self.stop_event = threading.Event()
        self.rx_queue: queue.Queue = queue.Queue()
        self.connected = False
        self.demo_mode = False
        self.demo_job = None
        self.water_job = None

        # Trạng thái giao diện & dữ liệu sống
        self.current_page = "dashboard"
        self.active_metric = "soil_pct"
        self.window_size = 30
        self.chart_paused = False
        self.pump_mode = "AUTO"
        self.last_save_ts = 0.0
        self.packet_count = 0
        self.zero_drops = 0

        self.live = {
            "soil_pct": None, "soil_mv": None, "soil_adc": None,
            "temp_c": None, "air_hum_pct": None, "light_lux": None, "press_hpa": None,
            "roll": None, "pitch": None, "ax": None, "ay": None, "az": None, "dyn_g": None,
            "tank_ok": None, "est_cycles": 18, "pump_on": False, "pump_phase": "IDLE", "cycles": 0,
            "rms": None, "peak": None, "dbfs": None,
        }
        self.series: dict[str, deque] = {k: deque(maxlen=300) for k in METRICS_CONFIG}
        self.i2c_found: set[str] = set()
        self.hover_points: list[tuple[int, int, float]] = []

        # Tk Variables
        self.port_var = tk.StringVar()
        self.baud_var = tk.StringVar(value="921600")
        self.dtr_var = tk.BooleanVar(value=False)
        self.thresh_var = tk.IntVar(value=30)
        self.save_rate_var = tk.StringVar(value="5")
        self.db_filter_var = tk.StringVar(value="Tất cả bản ghi")

        self.nav_buttons: dict[str, tk.Button] = {}
        self.pages: dict[str, tk.Frame] = {}
        self.kpi_widgets: dict[str, dict] = {}
        self.win_buttons: dict[int, tk.Button] = {}
        self.grp_buttons: dict[str, tk.Button] = {}
        self.i2c_dots: dict[str, tk.Label] = {}
        self.themed_hooks: list = []

        self._setup_styles()
        self._build_top_bar()
        self._build_body()
        self._apply_theme()

        self._refresh_ports()
        self.select_metric("soil_pct")
        self.switch_page("dashboard")

        self.root.bind("<Escape>", lambda _e: self.trigger_estop())
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(60, self._poll_rx_queue)
        self.root.after(1000, self._tick_clock)

        if not HAS_PYSERIAL:
            self._log_console("WARN", "Chưa cài thư viện pyserial! Hãy chạy: pip install pyserial")

    def c(self, key: str) -> str:
        return THEMES[self.theme_name][key]

    def _setup_styles(self):
        self.style = ttk.Style()
        self.style.theme_use("clam")

    # =========================================================================
    # TOP BAR (KẾT NỐI USB COM + TRẠNG THÁI + CHẾ ĐỘ MÀU)
    # =========================================================================
    def _build_top_bar(self):
        self.top_bar = tk.Frame(self.root, height=54, bd=0)
        self.top_bar.pack(fill="x")
        self.top_bar.pack_propagate(False)

        # Trái: Tiêu đề
        left = tk.Frame(self.top_bar)
        left.pack(side="left", padx=14, pady=6)
        self.lbl_brand = tk.Label(left, text="🌱 SMART PLANT MONITOR", font=("Segoe UI", 11, "bold"))
        self.lbl_brand.pack(anchor="w")
        self.lbl_subtitle = tk.Label(left, text="Trang 1 · Giám sát Môi trường & Thủy lợi Thực tế", font=("Segoe UI", 9))
        self.lbl_subtitle.pack(anchor="w")

        # Giữa: Cụm chọn cổng COM USB
        self.usb_box = tk.Frame(self.top_bar, bd=1, relief="solid", padx=8, pady=4)
        self.usb_box.pack(side="left", padx=16)

        self.lbl_com_title = tk.Label(self.usb_box, text="COM:", font=("Consolas", 10, "bold"))
        self.lbl_com_title.pack(side="left", padx=(0, 4))

        self.port_combo = ttk.Combobox(self.usb_box, textvariable=self.port_var, width=26, state="readonly", font=("Consolas", 9))
        self.port_combo.pack(side="left", padx=(0, 4))

        self.btn_refresh_com = tk.Button(self.usb_box, text="↻", width=3, relief="flat", font=("Segoe UI", 9, "bold"), command=self._refresh_ports, cursor="hand2")
        self.btn_refresh_com.pack(side="left", padx=2)

        self.lbl_baud_title = tk.Label(self.usb_box, text="Baud:", font=("Consolas", 9))
        self.lbl_baud_title.pack(side="left", padx=(8, 4))

        self.baud_combo = ttk.Combobox(self.usb_box, textvariable=self.baud_var, values=["921600", "115200"], width=8, state="readonly", font=("Consolas", 9))
        self.baud_combo.pack(side="left", padx=(0, 6))

        self.chk_dtr = tk.Checkbutton(self.usb_box, text="DTR", variable=self.dtr_var, font=("Consolas", 9, "bold"), bd=0, highlightthickness=0)
        self.chk_dtr.pack(side="left", padx=(0, 6))

        self.btn_connect = tk.Button(self.usb_box, text="🔌 Kết nối", relief="flat", padx=10, pady=2, font=("Segoe UI", 9, "bold"), command=self.toggle_connect, cursor="hand2")
        self.btn_connect.pack(side="left")

        # Phải: Trạng thái sống, Demo, Giao diện Sáng/Tối, Đồng hồ
        right = tk.Frame(self.top_bar)
        right.pack(side="right", padx=14)

        self.lbl_clock = tk.Label(right, text="--:--:--", font=("Consolas", 11, "bold"))
        self.lbl_clock.pack(side="right", padx=(10, 0))

        self.btn_theme = tk.Button(right, text="🎨 Tối", relief="flat", padx=9, pady=4, font=("Segoe UI", 9, "bold"), command=self.toggle_theme, cursor="hand2")
        self.btn_theme.pack(side="right", padx=4)

        self.btn_demo = tk.Button(right, text="🧪 Thử Demo", relief="flat", padx=9, pady=4, font=("Segoe UI", 9, "bold"), command=self.toggle_demo_mode, cursor="hand2")
        self.btn_demo.pack(side="right", padx=4)

        self.lbl_conn_pill = tk.Label(right, text="● CHƯA KẾT NỐI", font=("Consolas", 9, "bold"), padx=10, pady=4, bd=1, relief="solid")
        self.lbl_conn_pill.pack(side="right", padx=4)

        self.themed_hooks.append(("top", left, right))

    # =========================================================================
    # THÂN CHÍNH: SIDEBAR + 4 TRANG
    # =========================================================================
    def _build_body(self):
        self.body = tk.Frame(self.root)
        self.body.pack(fill="both", expand=True, padx=10, pady=(8, 10))

        # Sidebar gọn bên trái
        self.sidebar = tk.Frame(self.body, width=168, bd=1, relief="solid")
        self.sidebar.pack(side="left", fill="y", padx=(0, 10))
        self.sidebar.pack_propagate(False)

        self.lbl_nav_head = tk.Label(self.sidebar, text="ĐIỀU HƯỚNG", font=("Consolas", 9, "bold"), pady=8)
        self.lbl_nav_head.pack(fill="x")

        nav_items = [
            ("dashboard", "1. Giám sát Tổng quan"),
            ("database", "2. Kho Lịch sử SQLite"),
            ("settings", "3. Hiệu chuẩn & Tưới"),
            ("debug", "4. Serial & Chẩn đoán"),
        ]
        for key, label in nav_items:
            btn = tk.Button(
                self.sidebar, text=label, anchor="w", relief="flat", padx=10, pady=10,
                font=("Segoe UI", 9, "bold"), cursor="hand2", command=lambda k=key: self.switch_page(k),
            )
            btn.pack(fill="x", padx=8, pady=(6, 0))
            self.nav_buttons[key] = btn

        self.lbl_sidebar_note = tk.Label(
            self.sidebar,
            text="Hỗ trợ tự động:\n• sensor/src/main.cpp\n• Nhóm 1, 2, 3 riêng lẻ\n• Gói JSON Telemetry\n\nPhím Esc: Dừng bơm",
            font=("Segoe UI", 8), justify="left", anchor="w", padx=10, pady=10, bd=1, relief="solid",
        )
        self.lbl_sidebar_note.pack(side="bottom", fill="x", padx=8, pady=8)

        # Vùng chứa các trang
        self.page_container = tk.Frame(self.body)
        self.page_container.pack(side="left", fill="both", expand=True)

        for key in ("dashboard", "database", "settings", "debug"):
            self.pages[key] = tk.Frame(self.page_container)

        self._build_page_1_dashboard(self.pages["dashboard"])
        self._build_page_2_database(self.pages["database"])
        self._build_page_3_settings(self.pages["settings"])
        self._build_page_4_debug(self.pages["debug"])

    # =========================================================================
    # TRANG 1: GIÁM SÁT TỔNG QUAN (KHÔNG CẦN LĂN CHUỘT, 2 CỘT HÀI HÒA)
    # =========================================================================
    def _build_page_1_dashboard(self, parent: tk.Frame):
        parent.columnconfigure(0, weight=0, minsize=380)
        parent.columnconfigure(1, weight=1)
        parent.rowconfigure(0, weight=1)

        # CỘT TRÁI: CÂN BẰNG MPU-6050 + TRẠM TƯỚI P3
        self.col_left = tk.Frame(parent, width=380)
        self.col_left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.col_left.grid_propagate(False)
        self.col_left.rowconfigure(0, weight=1)
        self.col_left.rowconfigure(1, weight=1)
        self.col_left.columnconfigure(0, weight=1)

        # Card 1A: Nhóm cảm biến & MPU-6050
        self.card_imu = tk.Frame(self.col_left, bd=1, relief="solid", padx=12, pady=10)
        self.card_imu.grid(row=0, column=0, sticky="nsew", pady=(0, 10))

        head_imu = tk.Frame(self.card_imu)
        head_imu.pack(fill="x", pady=(0, 6))
        self.lbl_imu_title = tk.Label(head_imu, text="🧭 Cân bằng (MPU-6050) & Nhóm ESP32", font=("Segoe UI", 10, "bold"))
        self.lbl_imu_title.pack(side="left")
        self.lbl_imu_badge = tk.Label(head_imu, text="CHỜ DỮ LIỆU", font=("Consolas", 8, "bold"), padx=6, pady=2)
        self.lbl_imu_badge.pack(side="right")

        grp_row = tk.Frame(self.card_imu)
        grp_row.pack(fill="x", pady=(0, 8))
        for i in range(4):
            grp_row.columnconfigure(i, weight=1)
        for idx, (cmd, txt) in enumerate([("1", "1. Môi trường"), ("2", "2. MPU-6050"), ("3", "3. Micro"), ("s", "s. Quét I2C")]):
            b = tk.Button(grp_row, text=txt, relief="flat", pady=4, font=("Segoe UI", 8, "bold"), cursor="hand2", command=lambda c=cmd: self.send_serial_cmd(c))
            b.grid(row=0, column=idx, sticky="ew", padx=2)
            self.grp_buttons[cmd] = b

        self.imu_inner = tk.Frame(self.card_imu, bd=0, highlightthickness=1, padx=10, pady=8)
        self.imu_inner.pack(fill="both", expand=True)

        self.canvas_horizon = tk.Canvas(self.imu_inner, width=92, height=92, highlightthickness=0)
        self.canvas_horizon.pack(side="left", padx=(0, 12))

        imu_info = tk.Frame(self.imu_inner)
        imu_info.pack(side="left", fill="both", expand=True)
        self.lbl_tilt = tk.Label(imu_info, text="Roll / Pitch: -- / --", font=("Consolas", 10, "bold"), anchor="w")
        self.lbl_tilt.pack(fill="x", pady=(2, 2))
        self.lbl_acc = tk.Label(imu_info, text="Accel (g): --", font=("Consolas", 9), anchor="w")
        self.lbl_acc.pack(fill="x", pady=2)
        self.lbl_dyng = tk.Label(imu_info, text="Rung G-Force: --", font=("Consolas", 9), anchor="w")
        self.lbl_dyng.pack(fill="x", pady=2)

        self.imu_btns = tk.Frame(imu_info)
        self.imu_btns.pack(fill="x", pady=(6, 0))
        self.btn_cal_c = tk.Button(self.imu_btns, text="Calib ('c')", relief="flat", pady=3, font=("Segoe UI", 8, "bold"), cursor="hand2", command=lambda: self.send_serial_cmd("c"))
        self.btn_cal_c.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.btn_cal_z = tk.Button(self.imu_btns, text="Tare 0° ('z')", relief="flat", pady=3, font=("Segoe UI", 8, "bold"), cursor="hand2", command=lambda: self.send_serial_cmd("z"))
        self.btn_cal_z.pack(side="left", fill="x", expand=True)

        # Card 1B: Trạm Tưới An Toàn P3
        self.card_pump = tk.Frame(self.col_left, bd=1, relief="solid", padx=12, pady=10)
        self.card_pump.grid(row=1, column=0, sticky="nsew")

        head_p = tk.Frame(self.card_pump)
        head_p.pack(fill="x", pady=(0, 6))
        self.lbl_pump_title = tk.Label(head_p, text="💧 Trạm Tưới An Toàn (P3)", font=("Segoe UI", 10, "bold"))
        self.lbl_pump_title.pack(side="left")
        self.lbl_pump_phase = tk.Label(head_p, text="IDLE", font=("Consolas", 8, "bold"), padx=8, pady=2)
        self.lbl_pump_phase.pack(side="right")

        self.tank_inner = tk.Frame(self.card_pump, bd=1, relief="solid", padx=10, pady=7)
        self.tank_inner.pack(fill="x", pady=(0, 8))
        tank_top = tk.Frame(self.tank_inner)
        tank_top.pack(fill="x")
        self.lbl_tank_status = tk.Label(tank_top, text="Bình XKC-Y25: CHỜ TÍN HIỆU", font=("Consolas", 9, "bold"))
        self.lbl_tank_status.pack(side="left")
        self.btn_refill = tk.Button(tank_top, text="Đã châm đầy", relief="flat", padx=8, pady=2, font=("Segoe UI", 8, "bold"), cursor="hand2", command=self.refill_tank)
        self.btn_refill.pack(side="right")
        self.lbl_tank_est = tk.Label(self.tank_inner, text="Ước lượng: -- / 18 xung", font=("Consolas", 8), anchor="w")
        self.lbl_tank_est.pack(fill="x", pady=(4, 0))

        phase_row = tk.Frame(self.card_pump)
        phase_row.pack(fill="x", pady=(0, 6))
        for i in range(3):
            phase_row.columnconfigure(i, weight=1)
        self.lbl_ph_pump = tk.Label(phase_row, text="1. Bơm 3s", font=("Segoe UI", 8, "bold"), pady=4, bd=1, relief="solid")
        self.lbl_ph_soak = tk.Label(phase_row, text="2. Ngấm 2s", font=("Segoe UI", 8, "bold"), pady=4, bd=1, relief="solid")
        self.lbl_ph_check = tk.Label(phase_row, text="3. Đo lại %", font=("Segoe UI", 8, "bold"), pady=4, bd=1, relief="solid")
        self.lbl_ph_pump.grid(row=0, column=0, sticky="ew", padx=(0, 3))
        self.lbl_ph_soak.grid(row=0, column=1, sticky="ew", padx=3)
        self.lbl_ph_check.grid(row=0, column=2, sticky="ew", padx=(3, 0))

        self.lbl_cycles = tk.Label(self.card_pump, text="Chu kỳ liên tiếp (Chống tràn): 0 / 5", font=("Consolas", 9, "bold"), anchor="w")
        self.lbl_cycles.pack(fill="x", pady=(2, 4))

        ctrl_row = tk.Frame(self.card_pump)
        ctrl_row.pack(fill="x", pady=(0, 8))
        ctrl_row.columnconfigure(0, weight=1)
        ctrl_row.columnconfigure(1, weight=1)

        mode_box = tk.Frame(ctrl_row)
        mode_box.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        self.btn_mode_auto = tk.Button(mode_box, text="AUTO", relief="flat", pady=5, font=("Consolas", 9, "bold"), cursor="hand2", command=lambda: self.set_pump_mode("AUTO"))
        self.btn_mode_man = tk.Button(mode_box, text="MANUAL", relief="flat", pady=5, font=("Consolas", 9, "bold"), cursor="hand2", command=lambda: self.set_pump_mode("MANUAL"))
        self.btn_mode_auto.pack(side="left", fill="x", expand=True, padx=(0, 2))
        self.btn_mode_man.pack(side="left", fill="x", expand=True)

        thresh_box = tk.Frame(ctrl_row)
        thresh_box.grid(row=0, column=1, sticky="ew")
        self.lbl_thresh = tk.Label(thresh_box, text="Ngưỡng tưới: 30%", font=("Consolas", 9, "bold"), anchor="w")
        self.lbl_thresh.pack(fill="x")
        self.scale_thresh = tk.Scale(thresh_box, from_=10, to=80, orient="horizontal", variable=self.thresh_var, showvalue=False, highlightthickness=0, bd=0, command=self._on_thresh_change)
        self.scale_thresh.pack(fill="x")

        act_row = tk.Frame(self.card_pump)
        act_row.pack(fill="x", side="bottom")
        act_row.columnconfigure(0, weight=1)
        act_row.columnconfigure(1, weight=1)
        self.btn_water = tk.Button(act_row, text="💧 Tưới xung 3s", relief="flat", pady=7, font=("Segoe UI", 9, "bold"), cursor="hand2", command=self.trigger_water_pulse)
        self.btn_water.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        self.btn_estop = tk.Button(act_row, text="🛑 DỪNG (Esc)", relief="flat", pady=7, font=("Segoe UI", 9, "bold"), cursor="hand2", command=self.trigger_estop)
        self.btn_estop.grid(row=0, column=1, sticky="ew", padx=(5, 0))

        # CỘT PHẢI: 5 THẺ KPI MÀU SẮC + BIỂU ĐỒ FULL CHIỀU CAO
        self.col_right = tk.Frame(parent)
        self.col_right.grid(row=0, column=1, sticky="nsew")
        self.col_right.rowconfigure(0, weight=0)
        self.col_right.rowconfigure(1, weight=1)
        self.col_right.columnconfigure(0, weight=1)

        kpi_row = tk.Frame(self.col_right)
        kpi_row.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        for i in range(5):
            kpi_row.columnconfigure(i, weight=1)

        for idx, (m_key, cfg) in enumerate(METRICS_CONFIG.items()):
            pad = (0, 5) if idx == 0 else ((5, 0) if idx == 4 else (3, 3))
            card = tk.Frame(kpi_row, bd=0, highlightthickness=2, cursor="hand2")
            card.grid(row=0, column=idx, sticky="nsew", padx=pad)

            accent_bar = tk.Frame(card, height=4)
            accent_bar.pack(fill="x")
            body = tk.Frame(card, padx=10, pady=8)
            body.pack(fill="both", expand=True)

            lbl_t = tk.Label(body, text=cfg["icon_title"], font=("Segoe UI", 9, "bold"), anchor="w")
            lbl_t.pack(fill="x")
            lbl_v = tk.Label(body, text="--", font=("Consolas", 18, "bold"), anchor="w")
            lbl_v.pack(fill="x", pady=(4, 2))
            bullet_canvas = None
            if m_key == "soil_pct":
                bullet_canvas = tk.Canvas(body, height=8, highlightthickness=0)
                bullet_canvas.pack(fill="x", pady=(0, 3))
            lbl_s = tk.Label(body, text=cfg["sub_default"], font=("Segoe UI", 8), anchor="w")
            lbl_s.pack(fill="x")

            widgets_to_bind = [card, accent_bar, body, lbl_t, lbl_v, lbl_s]
            if bullet_canvas is not None:
                widgets_to_bind.append(bullet_canvas)
            for w in widgets_to_bind:
                w.bind("<Button-1>", lambda _e, k=m_key: self.select_metric(k))

            self.kpi_widgets[m_key] = {
                "card": card, "bar": accent_bar, "body": body,
                "title": lbl_t, "val": lbl_v, "sub": lbl_s, "bullet": bullet_canvas,
            }

        # Biểu đồ lớn
        self.card_chart = tk.Frame(self.col_right, bd=1, relief="solid", padx=12, pady=10)
        self.card_chart.grid(row=1, column=0, sticky="nsew")

        chart_head = tk.Frame(self.card_chart)
        chart_head.pack(fill="x", pady=(0, 6))

        head_left = tk.Frame(chart_head)
        head_left.pack(side="left")
        self.lbl_chart_title = tk.Label(head_left, text="📈 Đồ thị Thời gian thực: 1. Độ ẩm đất (%)", font=("Segoe UI", 10, "bold"), anchor="w")
        self.lbl_chart_title.pack(anchor="w")
        self.lbl_chart_stats = tk.Label(head_left, text="Số mẫu: 0 · MIN: -- · AVG: -- · MAX: --", font=("Consolas", 9), anchor="w")
        self.lbl_chart_stats.pack(anchor="w")

        head_right = tk.Frame(chart_head)
        head_right.pack(side="right")
        self.btn_clear_chart = tk.Button(head_right, text="🗑 Xóa", relief="flat", padx=8, pady=3, font=("Segoe UI", 8, "bold"), cursor="hand2", command=self.clear_series)
        self.btn_clear_chart.pack(side="right", padx=2)
        self.btn_pause_chart = tk.Button(head_right, text="⏸ Tạm dừng", relief="flat", padx=8, pady=3, font=("Segoe UI", 8, "bold"), cursor="hand2", command=self.toggle_pause_chart)
        self.btn_pause_chart.pack(side="right", padx=2)
        for n_pts in (120, 60, 30):
            b = tk.Button(head_right, text=f"{n_pts} mẫu", relief="flat", padx=8, pady=3, font=("Consolas", 8, "bold"), cursor="hand2", command=lambda n=n_pts: self.set_window_size(n))
            b.pack(side="right", padx=2)
            self.win_buttons[n_pts] = b

        self.canvas_chart = tk.Canvas(self.card_chart, highlightthickness=1)
        self.canvas_chart.pack(fill="both", expand=True)
        self.canvas_chart.bind("<Configure>", lambda _e: self.redraw_chart())
        self.canvas_chart.bind("<Motion>", self._on_chart_hover)
        self.canvas_chart.bind("<Leave>", lambda _e: self.canvas_chart.delete("tooltip"))

        self.themed_hooks.append(("p1", head_imu, grp_row, imu_info, self.imu_btns, head_p, tank_top, phase_row, ctrl_row, mode_box, thresh_box, act_row, kpi_row, chart_head, head_left, head_right))

    # =========================================================================
    # TRANG 2: KHO DỮ LIỆU SQLITE
    # =========================================================================
    def _build_page_2_database(self, parent: tk.Frame):
        self.card_db = tk.Frame(parent, bd=1, relief="solid", padx=12, pady=10)
        self.card_db.pack(fill="both", expand=True)

        bar = tk.Frame(self.card_db)
        bar.pack(fill="x", pady=(0, 8))
        self.lbl_db_title = tk.Label(bar, text="🗄 Kho Dữ liệu Thực tế (SQLite: sensor_records)", font=("Segoe UI", 10, "bold"))
        self.lbl_db_title.pack(side="left")

        self.btn_clear_db = tk.Button(bar, text="Xóa lịch sử DB", relief="flat", padx=10, pady=4, font=("Segoe UI", 9, "bold"), cursor="hand2", command=self.clear_database)
        self.btn_clear_db.pack(side="right", padx=4)
        self.btn_exp_json = tk.Button(bar, text="Xuất JSON", relief="flat", padx=10, pady=4, font=("Segoe UI", 9, "bold"), cursor="hand2", command=lambda: self.export_records("json"))
        self.btn_exp_json.pack(side="right", padx=4)
        self.btn_exp_csv = tk.Button(bar, text="Xuất CSV", relief="flat", padx=10, pady=4, font=("Segoe UI", 9, "bold"), cursor="hand2", command=lambda: self.export_records("csv"))
        self.btn_exp_csv.pack(side="right", padx=4)

        cmb = ttk.Combobox(bar, textvariable=self.db_filter_var, values=["Tất cả bản ghi", "Chỉ dữ liệu USB thật", "Sự kiện tưới", "Cảnh báo"], state="readonly", width=20)
        cmb.pack(side="right", padx=8)
        cmb.bind("<<ComboboxSelected>>", lambda _e: self.refresh_db_table())

        wrap = tk.Frame(self.card_db)
        wrap.pack(fill="both", expand=True)
        cols = ("id", "ts", "src", "soil", "mv", "temp", "rh", "lux", "hpa", "tilt", "tank", "pump")
        self.tree_db = ttk.Treeview(wrap, columns=cols, show="headings")
        heads = {
            "id": "ID", "ts": "Thời gian", "src": "Nguồn", "soil": "Đất (%)", "mv": "mV",
            "temp": "Nhiệt (°C)", "rh": "Ẩm KK (%)", "lux": "Lux", "hpa": "hPa",
            "tilt": "Tilt (°)", "tank": "XKC-Y25", "pump": "Bơm",
        }
        for c_id in cols:
            self.tree_db.heading(c_id, text=heads[c_id])
            self.tree_db.column(c_id, width=140 if c_id == "ts" else 78, anchor="center")

        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree_db.yview)
        self.tree_db.configure(yscrollcommand=vsb.set)
        self.tree_db.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.themed_hooks.append(("p2", bar, wrap))

    # =========================================================================
    # TRANG 3: HIỆU CHUẨN CẢM BIẾN & QUY TẮC TƯỚI
    # =========================================================================
    def _build_page_3_settings(self, parent: tk.Frame):
        parent.columnconfigure(0, weight=1)
        parent.columnconfigure(1, weight=1)
        parent.rowconfigure(0, weight=1)
        parent.rowconfigure(1, weight=1)

        self.c_set1 = tk.Frame(parent, bd=1, relief="solid", padx=14, pady=12)
        self.c_set1.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(0, 6))
        tk.Label(self.c_set1, text="🌱 1. Hiệu chuẩn Cảm biến Độ ẩm Đất (GPIO34)", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 8))
        self.lbl_cal_mv = tk.Label(self.c_set1, text="Điện áp ADC sống: -- mV", font=("Consolas", 11, "bold"))
        self.lbl_cal_mv.pack(anchor="w", pady=(0, 10))
        tk.Label(self.c_set1, text="• Để cảm biến khô ngoài không khí -> bấm Lấy mốc Khô ('d').\n• Nhúng phần vạch đo vào nước -> bấm Lấy mốc Ướt ('w').", justify="left", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 12))
        b_row1 = tk.Frame(self.c_set1)
        b_row1.pack(fill="x")
        tk.Button(b_row1, text="Lấy mốc Khô 0% ('d')", relief="flat", pady=7, font=("Segoe UI", 9, "bold"), command=lambda: self.send_serial_cmd("d")).pack(side="left", fill="x", expand=True, padx=(0, 4))
        tk.Button(b_row1, text="Lấy mốc Ướt 100% ('w')", relief="flat", pady=7, font=("Segoe UI", 9, "bold"), command=lambda: self.send_serial_cmd("w")).pack(side="left", fill="x", expand=True, padx=4)
        tk.Button(b_row1, text="Reset ('r')", relief="flat", pady=7, padx=10, font=("Segoe UI", 9, "bold"), command=lambda: self.send_serial_cmd("r")).pack(side="left")

        self.c_set2 = tk.Frame(parent, bd=1, relief="solid", padx=14, pady=12)
        self.c_set2.grid(row=0, column=1, sticky="nsew", padx=(6, 0), pady=(0, 6))
        tk.Label(self.c_set2, text="🧭 2. Hiệu chuẩn MPU-6050 & Micro INMP441", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 8))
        self.lbl_cal_mpu = tk.Label(self.c_set2, text="Góc Roll / Pitch: -- / --", font=("Consolas", 11, "bold"))
        self.lbl_cal_mpu.pack(anchor="w", pady=(0, 10))
        b_row2 = tk.Frame(self.c_set2)
        b_row2.pack(fill="x", pady=(0, 8))
        tk.Button(b_row2, text="Hiệu chuẩn 1000 mẫu ('c')", relief="flat", pady=7, font=("Segoe UI", 9, "bold"), command=lambda: self.send_serial_cmd("c")).pack(side="left", fill="x", expand=True, padx=(0, 4))
        tk.Button(b_row2, text="Tare 0° ('z')", relief="flat", pady=7, font=("Segoe UI", 9, "bold"), command=lambda: self.send_serial_cmd("z")).pack(side="left", fill="x", expand=True)
        b_row3 = tk.Frame(self.c_set2)
        b_row3.pack(fill="x")
        tk.Button(b_row3, text="Gain Mic - ('-')", relief="flat", pady=6, command=lambda: self.send_serial_cmd("-")).pack(side="left", fill="x", expand=True, padx=(0, 4))
        tk.Button(b_row3, text="Gain Mic + ('+')", relief="flat", pady=6, command=lambda: self.send_serial_cmd("+")).pack(side="left", fill="x", expand=True, padx=4)
        tk.Button(b_row3, text="Test REC:5", relief="flat", pady=6, command=lambda: self.send_serial_cmd("REC:5")).pack(side="left", fill="x", expand=True)

        self.c_set3 = tk.Frame(parent, bd=1, relief="solid", padx=14, pady=12)
        self.c_set3.grid(row=1, column=0, sticky="nsew", padx=(0, 6), pady=(6, 0))
        tk.Label(self.c_set3, text="💧 3. Thông số An toàn Tưới & Lưu DB", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 10))
        tk.Label(self.c_set3, text="• Xung bơm định lượng: 3.0 giây   |   Chờ ngấm: 2.0 giây\n• Giới hạn khóa lỗi cảm biến: 5 chu kỳ liên tiếp", justify="left", font=("Consolas", 9)).pack(anchor="w", pady=(0, 10))
        rate_row = tk.Frame(self.c_set3)
        rate_row.pack(fill="x")
        tk.Label(rate_row, text="Chu kỳ ghi SQLite (giây):", font=("Segoe UI", 9, "bold")).pack(side="left")
        ttk.Combobox(rate_row, textvariable=self.save_rate_var, values=["1", "5", "15", "30"], width=8, state="readonly").pack(side="right")

        self.c_set4 = tk.Frame(parent, bd=1, relief="solid", padx=14, pady=12)
        self.c_set4.grid(row=1, column=1, sticky="nsew", padx=(6, 0), pady=(6, 0))
        tk.Label(self.c_set4, text="ℹ️ 4. Hướng dẫn Cắm USB & Chạy Ngay", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 10))
        tk.Label(
            self.c_set4,
            text=(
                "1. Cắm cáp USB ESP32 vào máy tính.\n"
                "2. Bấm nút ↻ cạnh ô COM nếu mới cắm cáp.\n"
                "3. Chọn Baud 921600 (sensor/src/main.cpp, INMP441) hoặc 115200 (Nhóm 1, 2).\n"
                "4. Nếu dùng cổng USB Native trên ESP32-S3 mà chưa thấy chữ chạy, tích chọn ô DTR."
            ),
            justify="left", font=("Segoe UI", 9),
        ).pack(anchor="w")
        self.themed_hooks.append(("p3", b_row1, b_row2, b_row3, rate_row))

    # =========================================================================
    # TRANG 4: SERIAL MONITOR & CHẨN ĐOÁN BUS I2C / INMP441
    # =========================================================================
    def _build_page_4_debug(self, parent: tk.Frame):
        parent.columnconfigure(0, weight=1)
        parent.columnconfigure(1, weight=1)
        parent.rowconfigure(0, weight=0)
        parent.rowconfigure(1, weight=1)

        # Ô trên trái: I2C & Raw
        self.c_dbg1 = tk.Frame(parent, bd=1, relief="solid", padx=12, pady=10)
        self.c_dbg1.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(0, 8))
        h1 = tk.Frame(self.c_dbg1)
        h1.pack(fill="x", pady=(0, 6))
        tk.Label(h1, text="🔌 1. Bus I2C & Thông số Thô", font=("Segoe UI", 10, "bold")).pack(side="left")
        tk.Button(h1, text="Quét I2C ('s')", relief="flat", padx=8, pady=2, font=("Segoe UI", 8, "bold"), command=lambda: self.send_serial_cmd("s")).pack(side="right")

        i2c_grid = tk.Frame(self.c_dbg1)
        i2c_grid.pack(fill="x", pady=(0, 6))
        for col_i in range(3):
            i2c_grid.columnconfigure(col_i, weight=1)
        for idx, (addr, name) in enumerate(I2C_DEVICES):
            lbl = tk.Label(i2c_grid, text=f"● {name}", font=("Consolas", 8, "bold"), anchor="w", padx=6, pady=4, bd=1, relief="solid")
            lbl.grid(row=idx // 3, column=idx % 3, sticky="ew", padx=2, pady=2)
            self.i2c_dots[addr] = lbl

        self.lbl_dbg_raw = tk.Label(self.c_dbg1, text="Soil: -- | IMU: -- | Gói nhận: 0", font=("Consolas", 9), anchor="w")
        self.lbl_dbg_raw.pack(fill="x")

        # Ô trên phải: INMP441 RMS
        self.c_dbg2 = tk.Frame(parent, bd=1, relief="solid", padx=12, pady=10)
        self.c_dbg2.grid(row=0, column=1, sticky="nsew", padx=(6, 0), pady=(0, 8))
        h2 = tk.Frame(self.c_dbg2)
        h2.pack(fill="x", pady=(0, 6))
        tk.Label(h2, text="🎙 2. Micro INMP441 RMS Monitor", font=("Segoe UI", 10, "bold")).pack(side="left")
        tk.Button(h2, text="Bật Mic ('3')", relief="flat", padx=8, pady=2, font=("Segoe UI", 8, "bold"), command=lambda: self.send_serial_cmd("3")).pack(side="right")
        self.lbl_mic_stats = tk.Label(self.c_dbg2, text="RMS: --   |   Peak: --   |   dBFS: --   |   Rớt: 0", font=("Consolas", 10, "bold"), anchor="w")
        self.lbl_mic_stats.pack(fill="x", pady=(4, 6))
        self.canvas_vu = tk.Canvas(self.c_dbg2, height=22, highlightthickness=1)
        self.canvas_vu.pack(fill="x")

        # Ô dưới: Serial Console
        self.c_dbg3 = tk.Frame(parent, bd=1, relief="solid", padx=12, pady=10)
        self.c_dbg3.grid(row=1, column=0, columnspan=2, sticky="nsew")
        h3 = tk.Frame(self.c_dbg3)
        h3.pack(fill="x", pady=(0, 6))
        tk.Label(h3, text="💻 3. Serial Monitor Trực tiếp (ESP32 ↔ PC)", font=("Segoe UI", 10, "bold")).pack(side="left")
        tk.Button(h3, text="Xóa log", relief="flat", padx=8, pady=2, command=self._clear_console).pack(side="right", padx=2)
        tk.Button(h3, text="Menu ('h')", relief="flat", padx=8, pady=2, command=lambda: self.send_serial_cmd("h")).pack(side="right", padx=2)

        self.txt_console = tk.Text(self.c_dbg3, font=("Consolas", 9), bd=1, relief="solid", wrap="word")
        self.txt_console.pack(fill="both", expand=True, pady=(0, 6))

        cmd_row = tk.Frame(self.c_dbg3)
        cmd_row.pack(fill="x")
        self.ent_cmd = tk.Entry(cmd_row, font=("Consolas", 10), bd=1, relief="solid")
        self.ent_cmd.pack(side="left", fill="x", expand=True, ipady=4, padx=(0, 6))
        self.ent_cmd.bind("<Return>", lambda _e: self._send_entry_cmd())
        self.btn_send_cmd = tk.Button(cmd_row, text="Gửi lệnh", relief="flat", padx=14, pady=5, font=("Segoe UI", 9, "bold"), command=self._send_entry_cmd)
        self.btn_send_cmd.pack(side="right")

        self.themed_hooks.append(("p4", h1, i2c_grid, h2, h3, cmd_row))

    # =========================================================================
    # ÁP DỤNG BẢNG MÀU SÁNG / TỐI
    # =========================================================================
    def toggle_theme(self):
        self.theme_name = "light" if self.theme_name == "dark" else "dark"
        self.btn_theme.configure(text="🎨 Tối" if self.theme_name == "dark" else "🎨 Sáng")
        self._apply_theme()

    def _apply_theme(self):
        bg_app, bg_side, bg_card, bg_in = self.c("bg_app"), self.c("bg_sidebar"), self.c("bg_card"), self.c("bg_inner")
        fg, muted, border = self.c("text"), self.c("muted"), self.c("border")

        self.root.configure(bg=bg_app)
        self.top_bar.configure(bg=bg_card)
        self.usb_box.configure(bg=bg_in, highlightbackground=border)
        self.lbl_brand.configure(bg=bg_card, fg=self.c("emerald"))
        self.lbl_subtitle.configure(bg=bg_card, fg=muted)
        self.lbl_com_title.configure(bg=bg_in, fg=self.c("sky"))
        self.lbl_baud_title.configure(bg=bg_in, fg=muted)
        self.chk_dtr.configure(bg=bg_in, fg=muted, selectcolor=bg_card, activebackground=bg_in, activeforeground=fg)
        self.btn_refresh_com.configure(bg=bg_card, fg=fg)
        self.lbl_clock.configure(bg=bg_card, fg=fg)
        self.btn_theme.configure(bg=bg_in, fg=fg)
        self.btn_demo.configure(bg=self.c("amber_tint") if self.demo_mode else bg_in, fg=self.c("amber") if self.demo_mode else fg)

        self.body.configure(bg=bg_app)
        self.sidebar.configure(bg=bg_side)
        self.lbl_nav_head.configure(bg=bg_side, fg=muted)
        self.lbl_sidebar_note.configure(bg=bg_in, fg=muted)
        self.page_container.configure(bg=bg_app)
        for p in self.pages.values():
            p.configure(bg=bg_app)

        self.col_left.configure(bg=bg_app)
        self.col_right.configure(bg=bg_app)
        self.sidebar.configure(bg=bg_side, bd=0, highlightthickness=1, highlightbackground=border)
        for card in (self.card_imu, self.card_pump, self.card_chart, self.card_db, self.c_set1, self.c_set2, self.c_set3, self.c_set4, self.c_dbg1, self.c_dbg2, self.c_dbg3):
            card.configure(bg=bg_card, bd=0, highlightthickness=1, highlightbackground=border)
        for inner in (self.imu_inner, self.tank_inner):
            inner.configure(bg=bg_in, bd=0, highlightthickness=1, highlightbackground=border)
        for k_g, b_g in self.grp_buttons.items():
            b_g.configure(bg=self.c("sky_tint") if k_g == "1" else bg_in, fg=self.c("sky") if k_g == "1" else (self.c("emerald") if k_g == "s" else fg))

        self.canvas_horizon.configure(bg=bg_in)
        self.canvas_chart.configure(bg=bg_in, highlightbackground=border)
        self.canvas_vu.configure(bg=bg_in, highlightbackground=border)
        self.txt_console.configure(bg=bg_in, fg=fg, insertbackground=fg)
        self.ent_cmd.configure(bg=bg_in, fg=fg, insertbackground=fg)

        self.lbl_imu_title.configure(bg=bg_card, fg=fg)
        self.lbl_imu_badge.configure(bg=bg_in, fg=muted)
        self.lbl_tilt.configure(bg=bg_in, fg=self.c("sky"))
        self.lbl_acc.configure(bg=bg_in, fg=fg)
        self.lbl_dyng.configure(bg=bg_in, fg=muted)
        self.btn_cal_c.configure(bg=self.c("amber_tint"), fg=self.c("amber"))
        self.btn_cal_z.configure(bg=bg_card, fg=fg)

        self.lbl_pump_title.configure(bg=bg_card, fg=fg)
        self.lbl_pump_phase.configure(bg=self.c("sky_tint"), fg=self.c("sky"))
        self.lbl_tank_status.configure(bg=bg_in, fg=muted)
        self.lbl_tank_est.configure(bg=bg_in, fg=muted)
        self.btn_refill.configure(bg=self.c("sky_tint"), fg=self.c("sky"))
        self.lbl_cycles.configure(bg=bg_card, fg=muted)
        self.lbl_thresh.configure(bg=bg_card, fg=self.c("emerald"))
        self.scale_thresh.configure(bg=bg_card, troughcolor=bg_in, activebackground=self.c("emerald"))
        self.btn_water.configure(bg=self.c("sky"), fg=self.c("btn_fg_dark"))
        self.btn_estop.configure(bg=self.c("rose"), fg="#FFFFFF")

        self.lbl_chart_title.configure(bg=bg_card, fg=fg)
        self.lbl_chart_stats.configure(bg=bg_card, fg=muted)
        self.btn_clear_chart.configure(bg=bg_in, fg=fg)
        self.btn_pause_chart.configure(bg=bg_in, fg=fg)
        self.lbl_db_title.configure(bg=bg_card, fg=fg)
        self.btn_exp_csv.configure(bg=self.c("emerald"), fg=self.c("btn_fg_dark"))
        self.btn_exp_json.configure(bg=self.c("sky_tint"), fg=self.c("sky"))
        self.btn_clear_db.configure(bg=self.c("rose_tint"), fg=self.c("rose"))
        self.btn_send_cmd.configure(bg=self.c("sky"), fg=self.c("btn_fg_dark"))

        self.style.configure("Treeview", background=bg_in, foreground=fg, fieldbackground=bg_in, rowheight=24, font=("Consolas", 9))
        self.style.configure("Treeview.Heading", background=bg_card, foreground=self.c("sky"), font=("Consolas", 9, "bold"))

        for group in self.themed_hooks:
            for fr in group[1:]:
                if fr in (self.col_left, self.col_right):
                    fr.configure(bg=bg_app)
                else:
                    fr.configure(bg=bg_card)
        # Đặt lại nền các khung con trên Trang 1 & 3 & 4
        for w in self._iter_children(self.pages["dashboard"]):
            if isinstance(w, tk.Frame) and w not in (self.col_left, self.col_right, self.card_imu, self.card_pump, self.card_chart, self.imu_inner, self.tank_inner):
                if w.master in (self.col_right, self.col_left):
                    w.configure(bg=bg_app)
                elif w.master is self.imu_inner or w is self.imu_btns:
                    w.configure(bg=bg_in)
                elif w.master is self.tank_inner:
                    w.configure(bg=bg_in)
        for p_key in ("settings", "debug"):
            for w in self._iter_children(self.pages[p_key]):
                if isinstance(w, tk.Label) and w not in self.i2c_dots.values():
                    w.configure(bg=bg_card, fg=fg)
                elif isinstance(w, tk.Button) and w is not self.btn_send_cmd:
                    w.configure(bg=bg_in, fg=fg)
                elif isinstance(w, tk.Frame) and w not in (self.c_set1, self.c_set2, self.c_set3, self.c_set4, self.c_dbg1, self.c_dbg2, self.c_dbg3):
                    w.configure(bg=bg_card)

        self.switch_page(self.current_page)
        self.select_metric(self.active_metric)
        self.set_pump_mode(self.pump_mode, send_cmd=False)
        self.set_window_size(self.window_size)
        self._update_conn_ui()
        self._update_all_ui()

    def _iter_children(self, widget):
        for child in widget.winfo_children():
            yield child
            yield from self._iter_children(child)

    # =========================================================================
    # KẾT NỐI SERIAL THỰC TẾ (CẮM USB -> CHỌN COM -> CHẠY)
    # =========================================================================
    def _refresh_ports(self):
        items, preferred = detect_serial_ports()
        self.port_map = {label: dev for dev, label, _ in items}
        labels = [label for _, label, _ in items]
        self.port_combo["values"] = labels
        if preferred:
            match_lbl = next((lbl for dev, lbl, _ in items if dev == preferred), labels[0])
            self.port_var.set(match_lbl)
        elif labels:
            self.port_var.set(labels[0])
        else:
            self.port_var.set("Chưa thấy cổng COM (Cắm USB)")

    def toggle_connect(self):
        if self.connected:
            self._disconnect()
        else:
            self._connect()

    def _connect(self):
        if not HAS_PYSERIAL:
            messagebox.showerror("Thiếu pyserial", "Chưa cài thư viện pyserial!\nHãy mở terminal và chạy:\n\npip install pyserial")
            return
        sel = self.port_var.get().strip()
        port = self.port_map.get(sel, "")
        if not port:
            messagebox.showwarning("Chưa có cổng COM", "Không tìm thấy cổng COM ESP32.\nHãy cắm cáp USB rồi bấm nút ↻.")
            return

        if self.demo_mode:
            self.toggle_demo_mode()

        baud = int(self.baud_var.get())
        dtr = bool(self.dtr_var.get())
        try:
            self.ser = serial.Serial()
            self.ser.port = port
            self.ser.baudrate = baud
            self.ser.timeout = 0.2
            self.ser.dtr = dtr
            self.ser.rts = False
            self.ser.open()
        except Exception as exc:
            messagebox.showerror("Lỗi mở cổng COM", f"Không thể mở {port}: {exc}")
            self.ser = None
            return

        self.connected = True
        self.active_port = port
        self.stop_event.clear()
        self.reader_thread = threading.Thread(target=self._serial_read_loop, daemon=True)
        self.reader_thread.start()
        self._log_console("SYS", f"Đã kết nối {port} @ {baud} baud (DTR={dtr})")
        self._update_conn_ui()

    def _disconnect(self):
        self.stop_event.set()
        if self.reader_thread and self.reader_thread.is_alive():
            self.reader_thread.join(timeout=0.5)
        if self.ser is not None:
            try:
                self.ser.close()
            except Exception:
                pass
            self.ser = None
        self.connected = False
        self._log_console("SYS", "Đã ngắt kết nối cổng COM.")
        self._update_conn_ui()

    def _serial_read_loop(self):
        while not self.stop_event.is_set() and self.ser and self.ser.is_open:
            try:
                raw = self.ser.readline()
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
                if line:
                    self.rx_queue.put(("LINE", line))
            except Exception as exc:
                self.rx_queue.put(("ERR", str(exc)))
                break

    def _poll_rx_queue(self):
        updated_any = False
        for _ in range(120):
            try:
                kind, payload = self.rx_queue.get_nowait()
            except queue.Empty:
                break
            if kind == "ERR":
                self._disconnect()
                self._log_console("ERR", f"Mất kết nối USB: {payload}")
                messagebox.showwarning("Mất kết nối USB", f"Cổng COM đã ngắt: {payload}")
                break
            if kind == "LINE":
                self._handle_serial_line(payload)
                updated_any = True
        if updated_any:
            self._update_all_ui()
        self.root.after(60, self._poll_rx_queue)

    def send_serial_cmd(self, cmd: str):
        if not self.connected or not self.ser or not self.ser.is_open:
            if not self.demo_mode:
                messagebox.showinfo("Chưa kết nối ESP32", f"Hãy chọn cổng COM và bấm Kết nối trước khi gửi lệnh '{cmd}'.")
            return
        try:
            self.ser.write((cmd + "\n").encode("utf-8"))
            self._log_console("TX", cmd)
            if cmd in self.grp_buttons:
                for k, b in self.grp_buttons.items():
                    b.configure(bg=self.c("sky_tint") if k == cmd else self.c("bg_inner"), fg=self.c("sky") if k == cmd else self.c("text"))
        except Exception as exc:
            self._log_console("ERR", f"Gửi lệnh thất bại: {exc}")

    def _send_entry_cmd(self):
        txt = self.ent_cmd.get().strip()
        if txt:
            self.send_serial_cmd(txt)
            self.ent_cmd.delete(0, "end")

    def _handle_serial_line(self, line: str):
        self._log_console("RX", line)
        self.packet_count += 1
        parsed = TelemetryParser.parse_line(line)

        for k in ("soil_pct", "soil_mv", "soil_adc", "temp_c", "air_hum_pct", "light_lux", "press_hpa",
                  "roll", "pitch", "ax", "ay", "az", "dyn_g", "tank_ok", "pump_on", "pump_phase", "cycles",
                  "rms", "peak", "dbfs"):
            if k in parsed:
                self.live[k] = parsed[k]

        if parsed.get("mic_updated") and parsed.get("rms") == 0:
            self.zero_drops += 1

        if "i2c_addr" in parsed:
            self.i2c_found.add(parsed["i2c_addr"])
        if "i2c_addrs" in parsed:
            self.i2c_found.update(parsed["i2c_addrs"])

        if parsed.get("env_updated"):
            if not self.chart_paused:
                for m_key in METRICS_CONFIG:
                    if self.live[m_key] is not None:
                        self.series[m_key].append(self.live[m_key])

            now_s = datetime.datetime.now().timestamp()
            interval = int(self.save_rate_var.get())
            if now_s - self.last_save_ts >= interval:
                self.last_save_ts = now_s
                tilt_deg = max(abs(self.live["roll"] or 0.0), abs(self.live["pitch"] or 0.0)) if self.live["roll"] is not None else None
                self.db.insert_record(
                    {
                        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "source": "DEMO" if self.demo_mode else f"USB:{getattr(self, 'active_port', 'COM')}",
                        "soil_pct": self.live["soil_pct"],
                        "soil_mv": self.live["soil_mv"],
                        "soil_adc": self.live["soil_adc"],
                        "temp_c": self.live["temp_c"],
                        "air_hum_pct": self.live["air_hum_pct"],
                        "light_lux": self.live["light_lux"],
                        "press_hpa": self.live["press_hpa"],
                        "tilt_deg": tilt_deg,
                        "dyn_g": self.live["dyn_g"],
                        "tank_ok": self.live["tank_ok"],
                        "pump_on": self.live["pump_on"],
                    }
                )
                if self.current_page == "database":
                    self.refresh_db_table()

    # =========================================================================
    # ĐIỀU KHIỂN TƯỚI & CHẾ ĐỘ DEMO TÙY CHỌN
    # =========================================================================
    def trigger_water_pulse(self):
        if self.connected:
            self.send_serial_cmd("WATER:3")
        elif not self.demo_mode:
            messagebox.showinfo("Chưa kết nối", "Hãy cắm USB ESP32 và bấm Kết nối (hoặc bật Thử Demo).")
            return

        if self.live["tank_ok"] is False or self.live["cycles"] >= 5:
            return
        if self.water_job is not None:
            self.root.after_cancel(self.water_job)
        self._step_water(0)

    def _step_water(self, sec: int):
        if sec == 0:
            self.live["pump_on"] = True
            self.live["pump_phase"] = "PUMPING_3S"
            self.live["cycles"] = min(5, self.live["cycles"] + 1)
            self.live["est_cycles"] = max(0, self.live["est_cycles"] - 1)
        elif sec == 3:
            self.live["pump_on"] = False
            self.live["pump_phase"] = "SOAKING_2S"
        elif sec == 5:
            self.live["pump_phase"] = "RECHECK"
        elif sec >= 6:
            self.live["pump_phase"] = "IDLE"
            self.live["cycles"] = 0
            self._update_all_ui()
            return
        self._update_all_ui()
        self.water_job = self.root.after(900, lambda: self._step_water(sec + 1))

    def trigger_estop(self):
        if self.water_job is not None:
            self.root.after_cancel(self.water_job)
            self.water_job = None
        if self.connected:
            self.send_serial_cmd("ESTOP")
        self.live["pump_on"] = False
        self.live["pump_phase"] = "IDLE"
        self._update_all_ui()

    def refill_tank(self):
        self.live["tank_ok"] = True
        self.live["est_cycles"] = 18
        if self.connected:
            self.send_serial_cmd("TANK_REFILL")
        self._update_all_ui()

    def set_pump_mode(self, mode: str, send_cmd: bool = True):
        self.pump_mode = mode
        self.btn_mode_auto.configure(bg=self.c("sky") if mode == "AUTO" else self.c("bg_inner"), fg=self.c("btn_fg_dark") if mode == "AUTO" else self.c("text"))
        self.btn_mode_man.configure(bg=self.c("sky") if mode == "MANUAL" else self.c("bg_inner"), fg=self.c("btn_fg_dark") if mode == "MANUAL" else self.c("text"))
        if send_cmd and self.connected:
            self.send_serial_cmd(f"MODE:{mode}")

    def _on_thresh_change(self, val):
        v = int(float(val))
        self.lbl_thresh.configure(text=f"Ngưỡng tưới: {v}%")
        METRICS_CONFIG["soil_pct"]["threshold"] = float(v)
        self._draw_soil_bullet()
        if self.active_metric == "soil_pct":
            self.redraw_chart()

    def toggle_demo_mode(self):
        self.demo_mode = not self.demo_mode
        if self.demo_mode:
            if self.connected:
                self._disconnect()
            self.live["tank_ok"] = True
            self.btn_demo.configure(text="⏹ Tắt Demo", bg=self.c("amber_tint"), fg=self.c("amber"))
            self._emit_demo()
        else:
            if self.demo_job is not None:
                self.root.after_cancel(self.demo_job)
                self.demo_job = None
            self.btn_demo.configure(text="🧪 Thử Demo", bg=self.c("bg_inner"), fg=self.c("text"))
        self._update_conn_ui()

    def _emit_demo(self):
        if not self.demo_mode:
            return
        t = datetime.datetime.now().timestamp()
        line = json.dumps(
            {
                "soil_pct": round(56.0 + math.sin(t / 4.0) * 6.0, 1),
                "soil_mv": int(1900 - math.sin(t / 4.0) * 90),
                "temp_c": round(27.4 + math.cos(t / 6.0) * 0.6, 1),
                "air_hum_pct": round(58.0 + math.sin(t / 5.0) * 2.0, 1),
                "light_lux": int(460 + math.sin(t / 3.0) * 45),
                "press_hpa": 1008.5,
                "roll": round(1.2 + math.sin(t / 2.5) * 1.6, 1),
                "pitch": -0.6,
                "ax": 0.02, "ay": -0.01, "az": 0.99,
                "dyn_g": 0.06,
                "tank_ok": True,
            }
        )
        self._handle_serial_line(line)
        self._update_all_ui()
        self.demo_job = self.root.after(1500, self._emit_demo)

    # =========================================================================
    # CẬP NHẬT GIAO DIỆN & ĐỒ THỊ
    # =========================================================================
    def switch_page(self, key: str):
        self.current_page = key
        titles = {
            "dashboard": "Trang 1 · Giám sát Môi trường & Thủy lợi Thực tế",
            "database": "Trang 2 · Kho Dữ liệu SQLite & Xuất CSV/JSON",
            "settings": "Trang 3 · Hiệu chuẩn Cảm biến & Quy tắc Tưới",
            "debug": "Trang 4 · Serial Monitor & Chẩn đoán Phần cứng",
        }
        self.lbl_subtitle.configure(text=titles.get(key, ""))
        for k, btn in self.nav_buttons.items():
            on = k == key
            btn.configure(bg=self.c("sky_tint") if on else self.c("bg_sidebar"), fg=self.c("sky") if on else self.c("muted"))
        for f in self.pages.values():
            f.pack_forget()
        self.pages[key].pack(fill="both", expand=True)
        if key == "dashboard":
            self.redraw_chart()
        elif key == "database":
            self.refresh_db_table()

    def select_metric(self, metric_key: str):
        self.active_metric = metric_key
        for k, w in self.kpi_widgets.items():
            cfg = METRICS_CONFIG[k]
            col = self.c(cfg["color_key"])
            is_sel = k == metric_key
            bg_c = self.c(cfg["tint_key"]) if is_sel else self.c("bg_card")
            w["card"].configure(bg=bg_c, highlightthickness=2 if is_sel else 1, highlightbackground=col if is_sel else self.c("border"))
            w["bar"].configure(bg=col)
            w["body"].configure(bg=bg_c)
            w["title"].configure(bg=bg_c, fg=self.c("muted"))
            w["val"].configure(bg=bg_c, fg=col)
            w["sub"].configure(bg=bg_c, fg=self.c("muted"))
            if w["bullet"] is not None:
                w["bullet"].configure(bg=self.c("bg_inner"))
        self._draw_soil_bullet()
        self.redraw_chart()

    def set_window_size(self, n_pts: int):
        self.window_size = n_pts
        for n, btn in self.win_buttons.items():
            on = n == n_pts
            btn.configure(bg=self.c("sky") if on else self.c("bg_inner"), fg=self.c("btn_fg_dark") if on else self.c("text"))
        self.redraw_chart()

    def toggle_pause_chart(self):
        self.chart_paused = not self.chart_paused
        self.btn_pause_chart.configure(text="▶ Tiếp tục" if self.chart_paused else "⏸ Tạm dừng")

    def clear_series(self):
        for dq in self.series.values():
            dq.clear()
        self.redraw_chart()

    def _update_conn_ui(self):
        if self.connected:
            self.btn_connect.configure(text="⏹ Ngắt COM", bg=self.c("rose"), fg="#FFFFFF")
            self.lbl_conn_pill.configure(text=f"● LIVE · {getattr(self, 'active_port', 'COM')}", bg=self.c("emerald_tint"), fg=self.c("emerald"))
        elif self.demo_mode:
            self.btn_connect.configure(text="🔌 Kết nối", bg=self.c("emerald"), fg=self.c("btn_fg_dark"))
            self.lbl_conn_pill.configure(text="● CHẾ ĐỘ DEMO", bg=self.c("amber_tint"), fg=self.c("amber"))
        else:
            self.btn_connect.configure(text="🔌 Kết nối", bg=self.c("emerald"), fg=self.c("btn_fg_dark"))
            self.lbl_conn_pill.configure(text="● CHƯA KẾT NỐI", bg=self.c("bg_inner"), fg=self.c("muted"))

    def _update_all_ui(self):
        lv = self.live
        # 5 KPI
        self.kpi_widgets["soil_pct"]["val"].configure(text=f"{lv['soil_pct']:.1f}%" if lv["soil_pct"] is not None else "--")
        if lv["soil_pct"] is not None:
            th = self.thresh_var.get()
            sub_txt = f"Khô (<{th}%)" if lv["soil_pct"] < th else (f"{lv['soil_mv']} mV · Đủ ẩm" if lv["soil_mv"] else "Đủ ẩm")
            self.kpi_widgets["soil_pct"]["sub"].configure(text=sub_txt, fg=self.c("amber") if lv["soil_pct"] < th else self.c("emerald"))
        self._draw_soil_bullet()

        self.kpi_widgets["temp_c"]["val"].configure(text=f"{lv['temp_c']:.1f}°C" if lv["temp_c"] is not None else "--")
        self.kpi_widgets["air_hum_pct"]["val"].configure(text=f"{lv['air_hum_pct']:.1f}%" if lv["air_hum_pct"] is not None else "--")
        self.kpi_widgets["light_lux"]["val"].configure(text=f"{int(round(lv['light_lux']))}" if lv["light_lux"] is not None else "--")
        self.kpi_widgets["press_hpa"]["val"].configure(text=f"{lv['press_hpa']:.1f}" if lv["press_hpa"] is not None else "--")

        # MPU-6050
        r, p = lv["roll"], lv["pitch"]
        self.lbl_tilt.configure(text=f"Roll / Pitch: {r:+.1f}° / {(p or 0.0):+.1f}°" if r is not None else "Roll / Pitch: -- / --")
        self.lbl_acc.configure(text=f"Accel: {lv['ax']:+.2f}, {lv['ay']:+.2f}, {lv['az']:+.2f}g" if lv["ax"] is not None else "Accel (g): --")
        self.lbl_dyng.configure(text=f"Rung G-Force: {lv['dyn_g']:.2f}g" if lv["dyn_g"] is not None else "Rung G-Force: --")
        if r is not None:
            tilt_abs = max(abs(r), abs(p or 0.0))
            if (lv["dyn_g"] or 0.0) > 1.2:
                self.lbl_imu_badge.configure(text="RUNG MẠNH!", fg=self.c("rose"), bg=self.c("rose_tint"))
            elif tilt_abs > 45:
                self.lbl_imu_badge.configure(text="NGÃ >45°!", fg=self.c("rose"), bg=self.c("rose_tint"))
            elif tilt_abs > 15:
                self.lbl_imu_badge.configure(text="NGHIÊNG NHẸ", fg=self.c("amber"), bg=self.c("amber_tint"))
            else:
                self.lbl_imu_badge.configure(text="ỔN ĐỊNH", fg=self.c("emerald"), bg=self.c("emerald_tint"))
        self._draw_horizon(r or 0.0)

        # Trạm tưới P3
        self.lbl_pump_phase.configure(text=lv["pump_phase"])
        if lv["tank_ok"] is None:
            self.lbl_tank_status.configure(text="Bình XKC-Y25: CHỜ TÍN HIỆU", fg=self.c("muted"))
            self.lbl_tank_est.configure(text="Ước lượng: -- / 18 xung")
        elif lv["tank_ok"]:
            self.lbl_tank_status.configure(text="Bình XKC-Y25: ĐỦ NƯỚC", fg=self.c("emerald"))
            self.lbl_tank_est.configure(text=f"Ước lượng: ~{lv['est_cycles']} / 18 xung")
        else:
            self.lbl_tank_status.configure(text="Bình XKC-Y25: CẠN BÌNH!", fg=self.c("rose"))
            self.lbl_tank_est.configure(text="Ước lượng: 0 / 18 xung")

        for ph_lbl, ph_name in ((self.lbl_ph_pump, "PUMPING_3S"), (self.lbl_ph_soak, "SOAKING_2S"), (self.lbl_ph_check, "RECHECK")):
            on = lv["pump_phase"] == ph_name
            ph_lbl.configure(bg=self.c("sky_tint") if on else self.c("bg_inner"), fg=self.c("sky") if on else self.c("muted"))
        self.lbl_cycles.configure(text=f"Chu kỳ liên tiếp (Chống tràn): {lv['cycles']} / 5")

        # Debug & Hiệu chuẩn
        self.lbl_cal_mv.configure(text=f"Điện áp ADC sống: {lv['soil_mv']} mV" if lv["soil_mv"] is not None else "Điện áp ADC sống: -- mV")
        self.lbl_cal_mpu.configure(text=f"Góc Roll / Pitch: {r:+.1f}° / {(p or 0.0):+.1f}°" if r is not None else "Góc Roll / Pitch: -- / --")
        self.lbl_dbg_raw.configure(text=f"Soil: {lv['soil_mv'] or '--'}mV | IMU: {lv['roll'] if lv['roll'] is not None else '--'}° | Gói nhận: {self.packet_count}")

        for addr, lbl in self.i2c_dots.items():
            found = addr in self.i2c_found
            lbl.configure(bg=self.c("emerald_tint") if found else self.c("bg_inner"), fg=self.c("emerald") if found else self.c("muted"))

        if lv["rms"] is not None:
            self.lbl_mic_stats.configure(text=f"RMS: {lv['rms']}   |   Peak: {lv['peak']}   |   dBFS: {lv['dbfs']:.1f}   |   Rớt: {self.zero_drops}")
            self._draw_vu_meter(lv["rms"])

        self.redraw_chart()

    def _draw_soil_bullet(self):
        c = self.kpi_widgets["soil_pct"]["bullet"]
        if c is None:
            return
        c.delete("all")
        w = max(80, c.winfo_width())
        pct = self.live["soil_pct"]
        th = self.thresh_var.get()
        if pct is not None:
            fill_col = self.c("amber") if pct < th else self.c("emerald")
            c.create_rectangle(0, 1, int(w * max(0.0, min(100.0, pct)) / 100.0), 7, fill=fill_col, outline="")
        tx = int(w * th / 100.0)
        c.create_line(tx, 0, tx, 8, fill=self.c("text"), width=2)

    def _draw_horizon(self, roll_deg: float):
        c = self.canvas_horizon
        c.delete("all")
        cx, cy, rad = 46, 46, 40
        c.create_oval(cx - rad, cy - rad, cx + rad, cy + rad, outline=self.c("border"), width=2, fill=self.c("bg_card"))
        c.create_line(cx - rad, cy, cx + rad, cy, fill=self.c("grid_line"), dash=(2, 2))
        c.create_line(cx, cy - rad, cx, cy + rad, fill=self.c("grid_line"), dash=(2, 2))
        ang = math.radians(max(-60.0, min(60.0, roll_deg)))
        dx, dy = math.cos(ang) * 32, math.sin(ang) * 32
        c.create_line(cx - dx, cy - dy, cx + dx, cy + dy, fill=self.c("sky"), width=3)
        c.create_oval(cx - 5, cy - 5, cx + 5, cy + 5, fill=self.c("emerald"), outline="")

    def _draw_vu_meter(self, rms: int):
        c = self.canvas_vu
        c.delete("all")
        w, h = max(100, c.winfo_width()), max(18, c.winfo_height())
        pct = min(1.0, rms / 5000.0)
        bar_col = self.c("rose") if pct > 0.75 else (self.c("amber") if pct > 0.45 else self.c("emerald"))
        c.create_rectangle(0, 0, int(w * pct), h, fill=bar_col, outline="")

    def redraw_chart(self):
        c = self.canvas_chart
        c.delete("all")
        w, h = c.winfo_width(), c.winfo_height()
        if w < 100 or h < 100:
            return

        cfg = METRICS_CONFIG[self.active_metric]
        col = self.c(cfg["color_key"])
        vals = list(self.series[self.active_metric])[-self.window_size :]
        unit = cfg["unit"]

        if not vals:
            self.lbl_chart_title.configure(text=f"📈 Đồ thị Thời gian thực: {cfg['title']} ({unit})")
            self.lbl_chart_stats.configure(text="Số mẫu: 0 · MIN: -- · AVG: -- · MAX: --")
            c.create_text(w // 2, h // 2 - 12, text="Cắm USB ESP32 → Chọn cổng COM ở thanh trên → Bấm Kết nối", font=("Segoe UI", 11, "bold"), fill=self.c("sky"))
            c.create_text(w // 2, h // 2 + 14, text="Hỗ trợ sensor/src/main.cpp, Nhóm 1/2/3 hoặc JSON Telemetry (hoặc nhấn 🧪 Thử Demo)", font=("Segoe UI", 9), fill=self.c("muted"))
            return

        min_v, max_v, avg_v = min(vals), max(vals), sum(vals) / len(vals)
        th = self.thresh_var.get() if self.active_metric == "soil_pct" else cfg["threshold"]
        self.lbl_chart_title.configure(text=f"📈 Đồ thị Thời gian thực ({len(vals)} mẫu): {cfg['title']} ({unit})")
        self.lbl_chart_stats.configure(text=f"MIN: {min_v:.1f} {unit}  ·  AVG: {avg_v:.1f} {unit}  ·  MAX: {max_v:.1f} {unit}  ·  Ngưỡng: {th:.0f} {unit}")

        pad_l, pad_r, pad_t, pad_b = 54, 22, 20, 28
        pw, ph = w - pad_l - pad_r, h - pad_t - pad_b
        y_min, y_max = cfg["y_min"], cfg["y_max"]
        span = max(1e-5, y_max - y_min)

        def to_y(v: float) -> int:
            clamped = max(y_min, min(y_max, v))
            return pad_t + ph - int(((clamped - y_min) / span) * ph)

        # Vùng lý tưởng
        lo, hi = cfg["ideal"]
        c.create_rectangle(pad_l, to_y(hi), w - pad_r, to_y(lo), fill=self.c("emerald_tint"), outline="")

        # Lưới ngang
        for step in range(5):
            tv = y_min + (span * step / 4.0)
            ty = to_y(tv)
            c.create_line(pad_l, ty, w - pad_r, ty, fill=self.c("grid_line"))
            c.create_text(pad_l - 8, ty, text=f"{tv:.0f}", anchor="e", font=("Consolas", 8), fill=self.c("muted"))

        # Đường ngưỡng
        if y_min <= th <= y_max:
            y_th = to_y(th)
            c.create_line(pad_l, y_th, w - pad_r, y_th, fill=self.c("amber"), dash=(5, 3), width=1.5)
            c.create_text(pad_l + 8, y_th - 8, text=f"Ngưỡng: {th:.0f} {unit}", anchor="w", font=("Consolas", 8, "bold"), fill=self.c("amber"))

        # Chuỗi dữ liệu
        n = len(vals)
        pts: list[tuple[int, int]] = []
        for idx, v in enumerate(vals):
            x = pad_l + (pw // 2 if n == 1 else int((idx / (n - 1)) * pw))
            pts.append((x, to_y(v)))

        self.hover_points = [(x, y, vals[i]) for i, (x, y) in enumerate(pts)]
        if n >= 2:
            flat = [coord for pt in pts for coord in pt]
            poly = [pts[0][0], pad_t + ph] + flat + [pts[-1][0], pad_t + ph]
            c.create_polygon(*poly, fill=col, stipple="gray12", outline="")
            c.create_line(*flat, fill=col, width=2.5, smooth=False)
        for x, y in pts:
            c.create_oval(x - 3, y - 3, x + 3, y + 3, fill=col, outline=self.c("bg_card"), width=1.5)

    def _on_chart_hover(self, event):
        c = self.canvas_chart
        c.delete("tooltip")
        if not self.hover_points:
            return
        nearest = min(self.hover_points, key=lambda p: abs(p[0] - event.x))
        if abs(nearest[0] - event.x) > 22:
            return
        x, y, val = nearest
        unit = METRICS_CONFIG[self.active_metric]["unit"]
        c.create_line(x, 16, x, c.winfo_height() - 24, fill=self.c("muted"), dash=(2, 2), tags="tooltip")
        box_x = min(c.winfo_width() - 100, max(60, x))
        box_y = max(24, y - 20)
        c.create_rectangle(box_x - 44, box_y - 11, box_x + 44, box_y + 11, fill=self.c("bg_card"), outline=self.c("sky"), tags="tooltip")
        c.create_text(box_x, box_y, text=f"{val:.1f} {unit}", font=("Consolas", 9, "bold"), fill=self.c("text"), tags="tooltip")

    # =========================================================================
    # KHO LỊCH SỬ, LOG SERIAL & ĐÓNG APP
    # =========================================================================
    def refresh_db_table(self):
        for item in self.tree_db.get_children():
            self.tree_db.delete(item)
        flt = self.db_filter_var.get()
        th = self.thresh_var.get()
        for r in self.db.fetch_recent(300):
            _, _, src, soil, _, _, _, _, _, tilt, tank, pump = r
            if flt == "Chỉ dữ liệu USB thật" and src == "DEMO":
                continue
            if flt == "Sự kiện tưới" and not pump:
                continue
            if flt == "Cảnh báo" and not ((soil is not None and soil < th) or (tilt is not None and tilt > 45) or tank == 0):
                continue
            tank_txt = "--" if tank is None else ("ĐỦ NƯỚC" if tank else "CẠN")
            fmt_row = (
                r[0], r[1], r[2],
                f"{r[3]:.1f}%" if r[3] is not None else "--",
                r[4] if r[4] is not None else "--",
                f"{r[5]:.1f}" if r[5] is not None else "--",
                f"{r[6]:.1f}%" if r[6] is not None else "--",
                f"{int(r[7])}" if r[7] is not None else "--",
                f"{r[8]:.1f}" if r[8] is not None else "--",
                f"{r[9]:.1f}°" if r[9] is not None else "--",
                tank_txt,
                "ON" if r[11] else "OFF",
            )
            self.tree_db.insert("", "end", values=fmt_row)

    def export_records(self, fmt: str):
        rows = self.db.fetch_recent(5000)
        if not rows:
            messagebox.showinfo("Chưa có dữ liệu", "Chưa có bản ghi nào trong database để xuất.")
            return
        ext = f".{fmt}"
        path = filedialog.asksaveasfilename(defaultextension=ext, filetypes=[(fmt.upper(), f"*{ext}")], initialfile=f"esp32_plant_data{ext}")
        if not path:
            return
        cols = ["id", "timestamp", "source", "soil_pct", "soil_mv", "temp_c", "air_hum_pct", "light_lux", "press_hpa", "tilt_deg", "tank_ok", "pump_on"]
        if fmt == "csv":
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                w.writerow(cols)
                w.writerows(rows)
        else:
            payload = [dict(zip(cols, r)) for r in rows]
            with open(path, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=False)
        messagebox.showinfo("Xuất thành công", f"Đã lưu {len(rows)} bản ghi vào:\n{path}")

    def clear_database(self):
        if messagebox.askyesno("Xác nhận", "Xóa toàn bộ lịch sử trong bảng sensor_records?"):
            self.db.clear_all()
            self.refresh_db_table()

    def _log_console(self, tag: str, msg: str):
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        self.txt_console.insert("end", f"[{ts}] {tag:<4} {msg}\n")
        if int(float(self.txt_console.index("end-1c").split(".")[0])) > 400:
            self.txt_console.delete("1.0", "50.0")
        self.txt_console.see("end")

    def _clear_console(self):
        self.txt_console.delete("1.0", "end")

    def _tick_clock(self):
        self.lbl_clock.configure(text=datetime.datetime.now().strftime("%H:%M:%S"))
        self.root.after(1000, self._tick_clock)

    def _on_close(self):
        self._disconnect()
        self.db.close()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = SmartPlantDesktopApp(root)
    root.mainloop()
