@echo off
chcp 65001 >nul
cd /d "%~dp0"
python smart_plant_app.py
if errorlevel 1 (
    echo.
    echo [LOI] Khong chay duoc Python hoac thieu thu vien.
    echo Hay cai Python 3.10+ va chay: pip install -r requirements.txt
    pause
)
